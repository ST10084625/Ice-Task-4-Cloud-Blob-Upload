using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using YourProject.Services;

public class HomeController : Controller
{
    private readonly AzureBlobService _blobService;

    public HomeController()
    {
        // Hardcoded for simplicity; ideally use appsettings.json
        _blobService = new AzureBlobService(
            "Your_Connection_String",
            "your-container-name");
    }

    [HttpPost]
    public async Task<IActionResult> UploadFile(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return Content("No file selected");

        var blobUrl = await _blobService.UploadFileAsync(file);
        return Content($"File uploaded! Blob URL: {blobUrl}");
    }
}

